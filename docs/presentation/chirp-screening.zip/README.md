ChirpMotion generated native evidence.

Inspect manifest.json and the two case directories. All manifest files are included.
Regeneration requires the external complete source checkout identified by source_external_url; fixture_source is an external source locator, not a bundle file.
Two synthetic fixtures do not establish physical calibration or general accuracy.
